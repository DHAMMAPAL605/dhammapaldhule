package com.program.streamapi;

public class ReverseString {
	public static void main(String[] args) {
		
	String name="Swara";
	
	for(int i=name.length()-1; i>=0; i--) {
		System.out.print(name.charAt(i));
	}
  }
}
